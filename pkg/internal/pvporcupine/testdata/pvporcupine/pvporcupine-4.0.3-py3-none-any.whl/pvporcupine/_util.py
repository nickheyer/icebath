#
# Copyright 2020-2026 Picovoice Inc.
#
# You may not use this file except in compliance with the license. A copy of the license is located in the "LICENSE"
# file accompanying this source.
#
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
# an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.
#

import logging
import os
import platform as pf
import requests
import subprocess
from typing import Optional


log = logging.getLogger('PPN')
log.setLevel(logging.WARNING)


def _is_64bit():
    return '64bit' in pf.architecture()[0]


def _pv_linux_machine(machine):
    if machine == 'x86_64':
        return machine
    elif machine in ['aarch64', 'armv7l', 'armv6l']:
        arch_info = ('-' + machine) if _is_64bit() else ''
    else:
        raise NotImplementedError("Unsupported CPU architecture: `%s`" % machine)

    cpu_info = ''
    try:
        cpu_info = subprocess.check_output(['cat', '/proc/cpuinfo']).decode()
        cpu_part_list = [x for x in cpu_info.split('\n') if 'CPU part' in x]
        cpu_part = cpu_part_list[0].split(' ')[-1].lower()
    except Exception as error:
        raise RuntimeError("Failed to identify the CPU with '%s'\nCPU info: %s" % (error, cpu_info))

    if '0xb76' == cpu_part:
        return 'arm11' + arch_info
    elif '0xd03' == cpu_part:
        return 'cortex-a53' + arch_info
    elif '0xd08' == cpu_part:
        return 'cortex-a72' + arch_info
    elif "0xd0b" == cpu_part:
        return "cortex-a76" + arch_info
    elif machine == 'armv7l':
        log.warning(
            'WARNING: Please be advised that this device (CPU part = %s) is not officially supported by Picovoice. '
            'Falling back to the armv6-based (Raspberry Pi Zero) library. This is not tested nor optimal.' % cpu_part)
        return 'arm11'
    else:
        raise NotImplementedError("Unsupported CPU: '%s'." % cpu_part)


def _pv_platform():
    pv_system = pf.system()
    if pv_system not in {'Darwin', 'Linux', 'Windows'}:
        raise ValueError("Unsupported system '%s'." % pv_system)

    if pv_system == 'Linux':
        pv_machine = _pv_linux_machine(pf.machine())
    else:
        pv_machine = pf.machine()

    return pv_system, pv_machine


_PV_SYSTEM, _PV_MACHINE = _pv_platform()

_RASPBERRY_PI_MACHINES = {
    "arm11",
    "cortex-a53",
    "cortex-a72",
    "cortex-a76",
    "cortex-a53-aarch64",
    "cortex-a72-aarch64",
    "cortex-a76-aarch64"}


def pv_library_path(relative: str = "") -> str:
    if _PV_SYSTEM == 'Darwin':
        if _PV_MACHINE == 'x86_64':
            return os.path.join(os.path.dirname(__file__), relative, 'lib/mac/x86_64/libpv_porcupine.dylib')
        elif _PV_MACHINE == "arm64":
            return os.path.join(os.path.dirname(__file__), relative, 'lib/mac/arm64/libpv_porcupine.dylib')
    elif _PV_SYSTEM == 'Linux':
        if _PV_MACHINE == 'x86_64':
            return os.path.join(os.path.dirname(__file__), relative, 'lib/linux/x86_64/libpv_porcupine.so')
        elif _PV_MACHINE in _RASPBERRY_PI_MACHINES:
            return os.path.join(
                os.path.dirname(__file__),
                relative,
                'lib/raspberry-pi/%s/libpv_porcupine.so' % _PV_MACHINE)
    elif _PV_SYSTEM == 'Windows':
        if _PV_MACHINE.lower() == 'amd64':
            return os.path.join(os.path.dirname(__file__), relative, 'lib/windows/amd64/libpv_porcupine.dll')
        elif _PV_MACHINE.lower() == 'arm64':
            return os.path.join(os.path.dirname(__file__), relative, 'lib/windows/arm64/libpv_porcupine.dll')

    raise NotImplementedError('Unsupported platform.')


def pv_model_path(relative: str = "") -> str:
    return os.path.join(os.path.dirname(__file__), relative, 'lib/common/porcupine_params.pv')


def pv_keyword_files_subdir():
    if _PV_SYSTEM == 'Darwin':
        return 'mac'
    elif _PV_SYSTEM == 'Linux':
        if _PV_MACHINE == 'x86_64':
            return 'linux'
        elif _PV_MACHINE in _RASPBERRY_PI_MACHINES:
            return 'raspberry-pi'
    elif _PV_SYSTEM == 'Windows':
        return 'windows'

    raise NotImplementedError('Unsupported platform')


def pv_keyword_paths(relative: str = "") -> dict:
    keyword_files_dir = \
        os.path.join(os.path.dirname(__file__), relative, 'resources/keyword_files', pv_keyword_files_subdir())

    res = dict()
    for x in os.listdir(keyword_files_dir):
        res[x.rsplit('_')[0]] = os.path.join(keyword_files_dir, x)

    return res


VALID_LANGUAGES = ('de', 'en', 'es', 'fr', 'it', 'ja', 'ko', 'pt')
VALID_PLATFORMS = ('linux', 'mac', 'windows', 'raspberry-pi', 'wasm', 'android', 'ios')
PORCUPINE_PHRASE_MAX_LENGTH = 64
PV_API_URL = "https://rest.picovoice.ai/"


def pv_get_platform():
    if _PV_SYSTEM == 'Darwin':
        return 'mac'
    elif _PV_SYSTEM == 'Linux':
        if _PV_MACHINE == 'x86_64':
            return 'linux'
        elif _PV_MACHINE in _RASPBERRY_PI_MACHINES:
            return 'raspberry-pi'
    elif _PV_SYSTEM == 'Windows':
        return 'windows'

    raise NotImplementedError("Unsupported platform ('%s', '%s').", _PV_SYSTEM, _PV_MACHINE)


def pv_train_model(
        access_key: str,
        output_path: str,
        language: str,
        phrase: str,
        platform: Optional[str] = None) -> None:

    if language not in VALID_LANGUAGES:
        raise ValueError(f"Invalid language '{language}'")

    if platform is None:
        platform = pv_get_platform()

    if platform not in VALID_PLATFORMS:
        raise ValueError(f"Invalid platform '{platform}'")

    if len(phrase) == 0:
        raise ValueError("Phrase must not be empty")

    if len(phrase) > PORCUPINE_PHRASE_MAX_LENGTH:
        raise ValueError(f"Phrase must not exceed {PORCUPINE_PHRASE_MAX_LENGTH} characters")

    payload = {
        "platform": platform,
        "phrase": phrase
    }

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "x-api-key": access_key
    }

    url = f"{PV_API_URL}{language}/api/ppn"

    try:
        response = requests.post(url, json=payload, headers=headers, allow_redirects=True)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"HTTP {e.response.status_code}: {e.response.text}") from e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}") from e

    with open(output_path, 'wb') as f:
        f.write(response.content)
